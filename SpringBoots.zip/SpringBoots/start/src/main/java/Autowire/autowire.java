package Autowire;

public class autowire {

}
