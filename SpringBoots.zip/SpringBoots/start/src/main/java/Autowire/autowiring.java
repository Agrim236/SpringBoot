package Autowire;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class autowiring{
public static void main(String[] args) {
ApplicationContext applicationContext = new ClassPathXmlApplicationContext("ioc.xml");

depratment d1 = (depratment) applicationContext.getBean("mcd");
d1.start();



    }
}
