package Autowire;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

public class depratment {
     bowler s1;

    public depratment() {

    }
    public depratment(bowler s1) {
        System.out.println("The constructor has been called");
        this.s1 = s1;
    }


     @Autowired
     @Qualifier("s4")
     public void setDepartment(bowler s1) {
      this.s1 = s1;
       System.out.println("Using setter method");
     }

    public void start() {
        if (s1 == null) {
            System.out.println("It won't work");
        } else {
            s1.work();
        }
    }
}
