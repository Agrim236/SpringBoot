package Autowire;

public class bowler {
    public void work(){
        System.out.println("work has been perofrmed");
    }
}
