package pbean;



public class Ship {
   enginne ship;
   public Ship(enginne ship) {
       this.ship = ship;
   }
    public void start() {
        if (ship == null) {
            System.out.println("It will be unable to start");
        } else {
            System.out.println("ship has been sailed");
        }
    }
}
