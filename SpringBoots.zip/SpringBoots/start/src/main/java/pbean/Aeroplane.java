package pbean;

public class Aeroplane {
     enginne pello;
    public Aeroplane(enginne pello){
        this.pello =pello;
    }
    public void start() {
        if (pello == null) {
            System.out.println("It will be unable to start");
        } else {
            System.out.println("Aeroplane has taken off");
        }
    }
}
