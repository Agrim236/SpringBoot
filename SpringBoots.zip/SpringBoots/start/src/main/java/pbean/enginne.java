package pbean;

public class enginne {
    enginne(){
        System.out.println("the constructor has been called");
    }
}
