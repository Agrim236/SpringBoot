package bean;

public interface Engine {
public abstract void Start ();
}
