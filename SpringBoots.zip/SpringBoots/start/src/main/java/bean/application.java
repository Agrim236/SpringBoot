package bean;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import pbean.Aeroplane;
import pbean.Ship;

class Key{
    public void run(Engine key){
        key.Start();
    }
    public void nan(bike key){
        key.Start();
    }
}
public class application {
    public static void main(String[] args) {
     Engine key=new bike();
     Key K=new Key();
     K.run(key);// loose coupling//
     bike Bike=new bike();
     K.nan(Bike);
        //The main purpose of  IOC container is to achieve the loose coupling//
        ApplicationContext ac=new ClassPathXmlApplicationContext("ioc.xml");
        bike key1=ac.getBean("hello",bike.class);
        //it states the dependecy of XML file depends on the constructer of the above clas//
        key1.setspeed(65);
        //injecting dependency by using setter method//
        ApplicationContext bc=new ClassPathXmlApplicationContext("ioc.xml");
        car key2=bc.getBean("Hello", car.class);
        System.out.println(key2.speed);
        ApplicationContext ac1=new ClassPathXmlApplicationContext("ioc.xml");
        Ship s1=ac1.getBean("dset", Ship.class);
        ApplicationContext cb=new ClassPathXmlApplicationContext("ioc.xml");
        Aeroplane s1a=cb.getBean("pset", Aeroplane.class);
        s1.start();
        s1a.start();






    }
}