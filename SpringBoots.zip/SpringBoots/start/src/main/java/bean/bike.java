package bean;

class bike implements Engine {
    int speed;
    bike(){
        System.out.println("Constructer is called");
    }
    @Override
    public void Start(){
        System.out.println("Bike has been started");
    }
    public void setspeed(int speed){
        this.speed = speed;
        System.out.println("setspeed is "+speed);
    }

}
