package bean;

class car implements Engine {
    int speed;
    @Override
    public void Start() {
        System.out.println("car has been started");
    }
    car(int speed) {
        this.speed = speed;
        System.out.println(speed);

    }

}
