package com.jorney.start.models;

import java.util.List;

public interface PostService {
    Post CreateNewPost(Post post,Integer Userid) throws Exception;
    List<Post> findPostByUserId(Integer Userid);
    Post findPostById(Integer id) throws Exception;

    List<Post> findAllPost();
     String deletePost(Integer Postid,Integer Userid) throws Exception;

     Post ListPost(Integer Userid,Integer Postid) throws Exception;
}
