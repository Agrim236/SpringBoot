package com.jorney.start.models;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.RequestBody;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service

public class PostserviceImplmentation implements PostService{
    @Autowired
    Postrepositry postrepositry;
    @Autowired
    private Userservice userservice;

    @Override
    public Post CreateNewPost(Post post, Integer Userid) throws Exception {
        User user=userservice.getUserbyId(Userid);
        if(user==null){
            throw new Exception("The user does not exist");
        }
        Post newPost = new Post();
        newPost.setId(post.getId());
        newPost.setUser(user);
        newPost.setCaption(post.getCaption());
        newPost.setImage(post.getImage());
        LocalDateTime now = LocalDateTime.now();
        newPost.CreateTime(now);



        return postrepositry.save(newPost);
    }

    @Override
    public List<Post> findPostByUserId(Integer Userid) {
        List<Post> postbyUserId = postrepositry.findbyUserId(Userid);
        return postbyUserId;
    }

    @Override
    public Post findPostById(Integer id) throws Exception {
        Optional<Post> post = postrepositry.findById(id);
        if(!post.isPresent()){
            throw new Exception("The post does not exist");
        }
        return post.get();
    }



    @Override
    public List<Post> findAllPost() {
        List<Post>list = new ArrayList<>();
        list= postrepositry.findAll();
        return list;
    }

    @Override
    public String deletePost(Integer Postid, Integer Userid) throws Exception {
        Post newPost=findPostById(Postid);
        if(newPost==null){
            throw new Exception("The post does not exist");
        }
        User puser = userservice.getUserbyId(Userid);
        if(newPost.getUser()!=puser){
            throw new Exception("User identification does not match");
        }
        return "the Post has been deleted";
    }


    @Override
    public  Post ListPost(Integer Postid , Integer Userid) throws Exception {
       User user = userservice.getUserbyId(Userid);
       Post post = findPostById(Postid);
       if(post.liked.contains(user)){
           post.liked.remove(user);
       }else{
           post.liked.add(user);
       }

       postrepositry.save(post);
       return post;
    }

    
}
