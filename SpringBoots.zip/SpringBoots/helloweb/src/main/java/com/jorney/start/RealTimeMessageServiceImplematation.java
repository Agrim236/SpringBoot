package com.jorney.start;

import com.jorney.start.models.Userservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

import java.util.List;

@Service
public class RealTimeMessageServiceImplematation implements RealTimeMessageService {
    @Autowired
    private realtimemessageRepostry RealtimemessageRepostry;
    @Autowired
    private Chatservice chatservice;
    @Autowired
    private Userservice userservice;
    @Override
    public realtimemessage Createmessgae(Integer Userid,Integer chatid, realtimemessage Realtimemessage) throws Exception {
        realtimemessage Message=new realtimemessage();
        Chat reqChat=chatservice.findchatbyId(chatid);
        Message.setChat(reqChat);
        Message.setContent(Realtimemessage.getContent());
        Message.setTimestep(LocalDateTime.now());
        Message.setImage(Realtimemessage.getImage());
        Message.setUser(userservice.getUserbyId(Userid));
        RealtimemessageRepostry.save(Message);
        reqChat.getMessages().add(Message);

        return Message;
    }

    @Override
    public List<realtimemessage> chatmessages(Integer chatid) {
        List<realtimemessage>Messages=RealtimemessageRepostry.findbychatId(chatid);
        return Messages;
    }


}
