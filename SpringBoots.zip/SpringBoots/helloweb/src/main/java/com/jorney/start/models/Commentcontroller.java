package com.jorney.start.models;

import jakarta.persistence.criteria.CriteriaBuilder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class Commentcontroller {
    @Autowired
    Commentservice commentservice;
    @Autowired
    PostService postService;
    @Autowired
    Userservice userservice;
    @Autowired
    Commentreposity commentreposity;
    @PostMapping("comment/{postId}/{userId}")
    public Comment createComment(@RequestBody Comment comment, @PathVariable Integer postId, @PathVariable Integer userId) throws Exception {
        Post post = postService.findPostById(postId);
        User user = userservice.getUserbyId(userId);
        Comment newComment = commentservice.createComment(comment, postId, userId);
        System.out.println("Created Comment: " + newComment.message() ); // Debugging line

        return newComment;
    }
    @GetMapping("comment/{postId}")
    public List<Comment> showComment(@PathVariable Integer postId) throws Exception {
        List<Comment>totalcomment=commentservice.showComments(postId);
        return totalcomment;
    }
}
