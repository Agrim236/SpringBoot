package com.jorney.start.models;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@RestController
public class UserController {
    @Autowired
    UserRepositry userRepository;
    @Autowired
    private UserServiceImplementation userServiceImplementation;
    @Autowired
    private Userservice userservice;

    @GetMapping("post")
    //Get user method 1//
    public List<User> getUser() throws Exception {
        List<User> set = new ArrayList<>();
        set=userservice.getUsers();
        return set;
    }

    //registered user method 2//
    @PostMapping("/post")
    public User createUser(@RequestBody User user) {
        User newUser=userservice.RegisterUser(user);
        return newUser;
    }
    //get user method 3//
    @GetMapping("post/gettinguser")
    public List<User> GetUsers(){

        List<User> set = userRepository.findAll();

            return set;
        }
    //update User method 4//
    @PutMapping("post/{userId}")
    public User updateUser(@RequestBody User user,@PathVariable Integer userId) throws Exception {
        Optional<User> user1 = userRepository.findById(userId);
        User oldUser=userservice.UpdateUser(user,userId);
        return oldUser;
    }
    // getUserbyId method 5//
    @GetMapping("post/Use/{userId}")
     public User getuserbyId(@PathVariable Integer userId)throws Exception {
       User user = userservice.getUserbyId(userId);
       if(user == null) {
           throw new Exception("there is no user with id: " + userId);
       }
       return user;
    }
    // FollowUser method6//
    @PutMapping("post/{userId2}/{userId}")
    public User FollowUser(@PathVariable Integer userId2,@PathVariable Integer userId)throws Exception {
        User user = userservice.FollowedUser(userId,userId2);
        return user;
    }
    @GetMapping("/post/search")
    public List<User> searchUser(@RequestParam String keyword)  {
        List<User> set = userservice.searchUser(keyword);
        return set;
    }

    // SearchUser method8//




}
