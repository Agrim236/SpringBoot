package com.jorney.start.models;

import jakarta.persistence.*;

import java.time.LocalDateTime;
import java.util.List;

@Entity
public class Comment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)// For auto-increment
    @Column(name = "commentId")
    private Integer commentId;
    String message;
    String Name;
    @ManyToOne
    Post post;
    LocalDateTime date;
    @OneToMany
    List<User>liked;





    Comment(String message, User user, Post post, LocalDateTime date) {
        this.message = message;
        this.Name = user.getName();
        this.post = post;
        this.date = date;

    }
    public Comment(){

    }

    public String message() {
        return message;
    }

    public String getMessage() {
        return message;
    }

    public String getName() {
        return Name;
    }

    public Integer getCommentId() {
        return commentId;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    public String name(){
        return Name;
    }
    public Post Post(){
        return post;
    }
    public void setPost(Post post){
        this.post=post;
    }
    public void setName(String Name) {
        this.Name=Name;

    }
    public void settime(LocalDateTime currenttime){
        this.date=currenttime;
    }

}
