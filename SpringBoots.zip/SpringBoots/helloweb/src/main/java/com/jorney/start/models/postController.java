package com.jorney.start.models;

import com.jorney.start.Apiresponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;


@RestController
public class postController {
    @Autowired
    PostService postService;

    @PostMapping("/post/create/{userid}")
    public ResponseEntity<Post> CreatePost(@RequestBody Post post,@PathVariable Integer userid) throws Exception {
        Post newpost = postService.CreateNewPost(post, userid);
        return new ResponseEntity<>(newpost, HttpStatus.ACCEPTED);
    }
    @DeleteMapping("/post/delete/{userid}")
    public ResponseEntity<Apiresponse> DeletePost(@RequestBody Integer Postid, @PathVariable Integer Userid) throws Exception {
        String message=postService.deletePost(Postid, Userid);
        Apiresponse apiresponse=new Apiresponse(message,true);
        return new ResponseEntity<Apiresponse>(apiresponse, HttpStatus.OK);
    }
    @GetMapping("/post/U/{userid}")
    public ResponseEntity<List<Post>> FindpostbyUserid(@PathVariable Integer userid) throws Exception {
        List<Post>requiredpost=postService.findPostByUserId(userid);
        return new ResponseEntity<>(requiredpost, HttpStatus.ACCEPTED);
    }
    @GetMapping("/post/findallpost")
    public ResponseEntity<List<Post>> FindAllPost() throws Exception {
        List<Post>requiredpost=postService.findAllPost();
        return new ResponseEntity<>(requiredpost, HttpStatus.ACCEPTED);
    }
    @GetMapping("/post/{Postid}")
    public ResponseEntity<Post> FindPostById(@PathVariable Integer Postid) throws Exception {
        Post post=postService.findPostById(Postid);
        return new ResponseEntity<>(post, HttpStatus.ACCEPTED);
    }

    @PutMapping("/post/likeduser/{postId}/post/{Userid}")
    public ResponseEntity<Post> FindAllLikedPost(@PathVariable Integer postId,@PathVariable Integer Userid) throws Exception {
        Post newpost=postService.ListPost(postId,Userid);

        return new ResponseEntity<Post>(newpost, HttpStatus.ACCEPTED);
    }



}
