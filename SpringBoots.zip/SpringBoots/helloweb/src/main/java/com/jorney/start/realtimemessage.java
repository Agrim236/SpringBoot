package com.jorney.start;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.jorney.start.models.User;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Data
public class realtimemessage {
    @Id
    @GeneratedValue(strategy= GenerationType.AUTO)
    private Integer MessaageId;
    private String content;
    private String image;
    @ManyToOne
    private User user;
    @JsonIgnore
    @ManyToOne
    private Chat chat;
    private LocalDateTime timestep;







}
