package com.jorney.start.models;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class CommentserviceImplemnetation implements Commentservice {
    @Autowired
    Commentreposity commentreposity;
    @Autowired
    private PostService postService;
    @Autowired
    private Userservice userservice;
    @Autowired
    private Postrepositry postrepositry;


    @Override
    public Comment createComment(Comment comment, Integer postId, Integer UserId) throws Exception {
        User user = userservice.getUserbyId(UserId);
        String name = user.getName();
        Post post = postService.findPostById(postId);

        // Ensure the Post is saved if it is not already
        if (postId== null) {
            postrepositry.save(post); // Save the Post if it is new
        }

        Comment newComment = new Comment();
        newComment.setMessage(comment.message());
        newComment.setName(user.getName());
        LocalDateTime currenttime = LocalDateTime.now();
        newComment.settime(currenttime);
        newComment.setPost(post); // Set the existing Post

        // Add the new comment to the Post's comment list



        commentreposity.save(newComment);

        return newComment;
    }



    @Override
    public Comment like(User user, Comment comment) {
        List<User>Like=comment.liked;
        if(comment.liked.contains(user)){
            comment.liked.remove(user);
        }else{
            comment.liked.add(user);
        }
        commentreposity.save(comment);
        return comment;
    }

    @Override
    public List<Comment> showComments(Integer postId) throws Exception {
        Post post=postService.findPostById(postId);
        List<Comment>totalcomments=post.comment;
        return totalcomments;
    }
}
