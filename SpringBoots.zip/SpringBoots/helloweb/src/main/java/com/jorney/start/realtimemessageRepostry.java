package com.jorney.start;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Repository
public interface realtimemessageRepostry extends JpaRepository<realtimemessage,Integer> {

    @Query("SELECT r FROM realtimemessage r WHERE r.chat.id = :chatid")
    List<realtimemessage>findbychatId(@Param("chatid")Integer chatId);

}
