package com.jorney.start;

import com.jorney.start.models.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Service
public class ChatServiceImplementation implements Chatservice {
    @Autowired
    private ChatRePositry chatRePositry;
    @Override
    public Chat createChat(User requserid1, User Userid) {
        Chat isExist=chatRePositry.findbyUser(requserid1,Userid);
        if(isExist!=null){
           return isExist;
        }
        Chat chat=new Chat();
        chat.getUsers().add(requserid1);
        chat.getUsers().add(Userid);
        chat.setTimestemp(LocalTime.now());

        return chatRePositry.save(chat);

    }

    @Override
    public List<Chat> findChatbyUserId(Integer Userid) {
        List<Chat>chat=chatRePositry.findsbyUserId(Userid);
        return chat;
    }

    @Override
    public Chat findchatbyId(Integer id) {
        Optional<Chat> newchat=chatRePositry.findById(id);
        return newchat.get();
    }

}
