package com.jorney.start;

public class Apiresponse {
    String message;
    boolean status;
    public String getMessage() {
        return message;

    }
    public void setMessage(String message) {
        this.message = message;
    }
    public boolean isStatus() {
        return status;
    }
    public void setStatus(boolean status) {
        this.status = status;

    }
    public Apiresponse(String message, boolean status) {
        this.message = message;
    }
    public Apiresponse() {

    }


}
