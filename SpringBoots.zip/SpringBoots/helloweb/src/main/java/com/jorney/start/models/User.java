package com.jorney.start.models;



import jakarta.persistence.*;

import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "raja")
public class User {
    @Id
    //@GeneratedValue(strategy = GenerationType.IDENTITY) // Use auto-increment strategy
    private Integer id;
    private String name;


    private int age;



    private String email;
    private String Grade;
    private List<Integer>Follower=new ArrayList<>();
    private List<Integer>Following=new ArrayList<>();
    @OneToMany(mappedBy = "user", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<Post> posts = new ArrayList<>();
    public User(int id, String name, int age, String email, String grade, List<Integer> following,List<Integer>Follower) {
        this.id = id;
        this.name = name;
        this.age = age;
        this.email = email;
        this.Grade = grade;
        this.Follower = Follower;
        this.Following = following;
    }

    public User() {

    }


    public List<Integer> getFollower() {

        return this.Follower;
    }
    public void addFollower(Integer id) {
        this.Follower.add(id);
    }
    public void addFolllowing(Integer id) {
        this.Following.add(id);
    }

    public List<Integer> getFollowing() {

        return Following;
    }


    public void setId(int id) {

        this.id = id;
    }
    public void setAge(int age) {

        this.age = age;
    }
    public void setEmail(String email) {

        this.email = email;
    }
    public void setGrade(String grade) {

        this.Grade = grade;
    }
    public void setName(String name)
    {

        this.name = name;
    }

    public int getId() {

        return this.id;
    }
    public int getage() {

        return this.age;
    }
    public String getemail() {

        return this.email;
    }
    public String getGrade() {

        return this.Grade;
    }
    public String getName() {

        return this.name;
    }

}
