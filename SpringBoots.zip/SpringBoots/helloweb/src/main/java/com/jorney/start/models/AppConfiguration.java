package com.jorney.start.models;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableWebSecurity
public class AppConfiguration {  // Fixed class name spelling

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/api/**").authenticated()  // Secure /api/** endpoints
                        .anyRequest().permitAll()  // Allow all other requests
                )
                .csrf(csrf -> csrf.disable());  // Disable CSRF (only for testing)

        return http.build();  // Return the built security config
    }
}
