package com.jorney.start.models;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class UserServiceImplementation implements Userservice{

    @Autowired
    UserRepositry userRepositry;
    @Override
    public User RegisterUser(User user){
        User newUser=new User();
        newUser.setId(user.getId());
        newUser.setName(user.getName());
        newUser.setAge(user.getage());
        newUser.setEmail(user.getemail());
        newUser.setGrade(user.getGrade());
        userRepositry.save(newUser);
        return newUser;
    }

    @Override
    public  User getUserbyId(Integer id) throws Exception {
        Optional<User> reqiredUser=userRepositry.findById(id);
        if(!reqiredUser.isPresent()) {
            throw new Exception("the user is not present with userId " + id);
        }
        return reqiredUser.get();
    }


   @Override
    public List<User> getUsers() throws Exception {
        if(userRepositry.findAll().isEmpty()){
            throw new Exception("No user found");
        }
        return userRepositry.findAll();
    }
    @Override
    public User UpdateUser(User user,int id) throws Exception{
        Optional<User> reqiredUser=userRepositry.findById(id);
       if(!userRepositry.findById(id).isPresent()){
           throw new Exception("the user is not present with userId "+id);
       }
       User olduser=reqiredUser.get();
        if(olduser.getGrade() !=null) {
            olduser.setGrade(user.getGrade());
        }
        if(olduser.getName() !=null) {
            olduser.setName(user.getName());
        }

        olduser.setAge(user.getage());

        olduser.setEmail(user.getemail());
        userRepositry.save(olduser);
        return olduser;
    }



    @Override
    public User getUserbyEmail(String email){
        Optional<User>RequiredUser=userRepositry.findByEmail(email);
        if(RequiredUser.isPresent()){
            userRepositry.save(RequiredUser.get());
        }
        return RequiredUser.get();
    }
    @Override
    public User FollowUser(Integer userid1,Integer userid2){
        User user1=userRepositry.findById(userid1).get();
        User user2=userRepositry.findById(userid2).get();
        user2.addFollower(userid1);
        user2.addFolllowing(userid1);
        userRepositry.save(user2);
        userRepositry.save(user1);
        return user1;
    }


    @Override
    public User FollowedUser(Integer userId1, Integer userId2) {
        User user1=userRepositry.findById(userId1).get();
        User user2=userRepositry.findById(userId2).get();
        user2.addFollower(userId1);
        user1.addFolllowing(userId2);
        userRepositry.save(user2);
        userRepositry.save(user1);
        return user2;
    }
    @Override
    public List<User> searchUser(String query) {
        return userRepositry.searchUser(query);
    }




}
