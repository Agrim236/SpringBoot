package com.jorney.start;

import com.jorney.start.models.User;

import java.util.List;

public interface Chatservice {
    public Chat createChat(User user, User reqUser2);
    public List<Chat> findChatbyUserId(Integer Userid);
    public Chat findchatbyId(Integer id);

}
