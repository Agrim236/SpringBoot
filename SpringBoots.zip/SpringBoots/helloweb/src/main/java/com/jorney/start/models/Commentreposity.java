package com.jorney.start.models;

import org.springframework.data.jpa.repository.JpaRepository;

public interface Commentreposity extends JpaRepository<Comment,Integer> {

}
