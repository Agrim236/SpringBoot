package com.jorney.start;

import  java.util.List;

public interface RealTimeMessageService {
    public realtimemessage Createmessgae(Integer UserId,Integer chatID,realtimemessage Message) throws Exception;

    public List<realtimemessage>chatmessages(Integer chatid);

}
