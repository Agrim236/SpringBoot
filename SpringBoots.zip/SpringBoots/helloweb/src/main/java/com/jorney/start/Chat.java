package com.jorney.start;

import com.jorney.start.models.User;
import jakarta.persistence.*;
import lombok.Data;

import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;


@Entity
@Data
public class Chat {
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer id;
    private String chat_name;
    private String chat_image;
    @ManyToMany
    private List<User>users=new ArrayList<>();
    private LocalTime timestemp;
    @OneToMany(mappedBy = "chat")
    private List<realtimemessage> messages=new ArrayList<>();




}
