package com.jorney.start.models;

import com.jorney.start.Chat;
import com.jorney.start.Chatservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController

public class Chatcontroller {
    @Autowired
    private Chatservice chatservice;
    @Autowired
    private Userservice userservice;
    @PostMapping("chat/{Userid1}/{UserId2}")
    public Chat createchat(@PathVariable Integer Userid1, @PathVariable Integer UserId2) throws Exception {
        User user1=userservice.getUserbyId(Userid1);
        User user2=userservice.getUserbyId(UserId2);
        Chat chat=chatservice.createChat(user1,user2);
        return chat;
    }
    @GetMapping("chat/{Userid1}")
    public List<Chat> getallChatbuserId(@PathVariable Integer Userid1) throws Exception {
        User user1=userservice.getUserbyId(Userid1);
        List<Chat>chat=chatservice.findChatbyUserId(Userid1);
        return chat;
    }
}
