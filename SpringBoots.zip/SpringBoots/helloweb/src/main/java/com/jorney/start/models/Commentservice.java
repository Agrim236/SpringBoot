package com.jorney.start.models;

import java.util.List;

public interface Commentservice {
     Comment createComment(Comment comment,Integer userid,Integer postId) throws Exception;
     Comment like(User user,Comment comment);
     List<Comment> showComments(Integer postId) throws Exception;
}
