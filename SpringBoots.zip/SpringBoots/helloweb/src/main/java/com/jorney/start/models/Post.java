package com.jorney.start.models;

import jakarta.persistence.*;


import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name="Posta")
public class Post {
    @Id
    private int id;
    private String Image;
    private String Caption;
    private LocalDateTime CreateTime;
    @ManyToOne
    private User user;
    @OneToMany
    List<User> liked = new ArrayList<>();
    @OneToMany(mappedBy = "post", cascade = CascadeType.ALL, orphanRemoval = true)
    List<Comment>comment=new ArrayList<>();




    public Post() {

    }
    public Post(int id, String image, String caption, LocalDateTime createTime, User user) {
        this.id = id;
        this.Image = image;
        this.Caption = caption;
        this.CreateTime = createTime;
        this.user = user;

    }




    public String getImage() {

        return this.Image;
    }

    public void setImage(String image) {
        Image = image;
    }
    public void setId(int id) {
        this.id=id;
    }
    public int getId() {
        return this.id;
    }
    public String getCaption() {

        return this.Caption;
    }


    public void setCaption(String caption) {

        Caption = caption;
    }
    public void CreateTime(LocalDateTime createTime) {
        CreateTime = createTime;

    }
    public LocalDateTime CreateTime() {

        return this.CreateTime;
    }
    public User getUser() {
        return this.user;

    }
    public void setUser(User user) {
        this.user = user;
    }


}
