package com.jorney.start.models;


import java.util.List;

public interface Userservice {
    public User RegisterUser(User user);
    public User getUserbyId(Integer id) throws Exception;
    public List<User> getUsers() throws Exception;

    public User getUserbyEmail(String name);
    public User FollowUser(Integer userId1, Integer userId2);
    public User FollowedUser(Integer userId1, Integer userId2);
    public User UpdateUser(User user,int id) throws Exception;
    public List<User> searchUser(String query);

}
