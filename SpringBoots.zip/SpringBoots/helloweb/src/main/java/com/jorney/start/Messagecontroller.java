package com.jorney.start;

import com.jorney.start.models.User;
import com.jorney.start.models.Userservice;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
public class Messagecontroller {
    @Autowired
    private Userservice userservice;
    @Autowired
    private ChatRePositry chatRePositry;
    @Autowired
    private RealTimeMessageService realTimeMessageService;
    @PostMapping("createmessage/{userid1}/{userid2}")
    public realtimemessage CreateMessage(@PathVariable Integer userid1, @PathVariable Integer userid2, @RequestBody realtimemessage message) throws Exception {
        User user1=userservice.getUserbyId(userid1);
        User user2=userservice.getUserbyId(userid2);
        Chat chat=chatRePositry.findbyUser(user1,user2);
        Integer chatid=chat.getId();
        realtimemessage Message=realTimeMessageService.Createmessgae(userid1,chatid, message);
        return Message;
    }
    @GetMapping("getmessages/{Userid}/{Userid2}")
    public List<realtimemessage> getallChats(@PathVariable Integer Userid, @PathVariable Integer Userid2) throws Exception {
        User user1=userservice.getUserbyId(Userid);
        User user2=userservice.getUserbyId(Userid2);
        Chat chat=chatRePositry.findbyUser(user1,user2);
        Integer chatid=chat.getId();
        List<realtimemessage>messages=realTimeMessageService.chatmessages(chatid);
        return messages;
    }




}
