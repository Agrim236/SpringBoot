import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class FirstandLastOccurence {
    public static List<Integer> Binary(int array[], int key) {
        int l = 0;
        int h = array.length - 1;
        List<Integer> list = new ArrayList<>();
        int first = -1, last = -1;

        // Finding the first occurrence
        while (l <= h) {
            int mid = l + (h - l) / 2;
            if (array[mid] == key) {
                first = mid;
                h = mid - 1; // Narrow down to the left half
            } else if (array[mid] < key) {
                l = mid + 1;
            } else {
                h = mid - 1;
            }
        }

        // Resetting l and h for finding the last occurrence
        l = 0;
        h = array.length - 1;

        // Finding the last occurrence
        while (l <= h) {
            int mid = l + (h - l) / 2;
            if (array[mid] == key) {
                last = mid;
                l = mid + 1; // Narrow down to the right half
            } else if (array[mid] < key) {
                l = mid + 1;
            } else {
                h = mid - 1;
            }
        }

        // Adding results to the list
        list.add(first);
        list.add(last);

        return list;
    }

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int n = sc.nextInt();
        int[] A = new int[n];
        for (int i = 0; i < n; i++) {
            A[i] = sc.nextInt();
        }
        int key = sc.nextInt();

        List<Integer> list = Binary(A, key);

        for (int i = 0; i < list.size(); i++) {
            System.out.println(list.get(i));
        }
    }
}
