import java.util.Scanner;

public class SearchinRotatedSortedArray {
    public static int find(int x, int[] arr) {
        int L = 0;
        int R = arr.length - 1;
        int K = R;
        boolean flag = false;
        int lowerLimit = 0;
        int UpperlimitIndex = 0;
        if (arr[0] > x) {

            flag = true;
        }
        boolean pflag = false;
        if (arr[0] < arr[R] ){
            pflag = true;
            UpperlimitIndex = K;
            lowerLimit = 0;
        }
        while (L <= R && !pflag) {
            int mid = L + R;
            mid = mid / 2;
            if (mid > 0 && arr[mid - 1] > arr[mid]) {
                if (!flag) {
                    UpperlimitIndex = mid - 1;
                    lowerLimit = 0;
                    break;
                } else {
                    lowerLimit = mid;
                    UpperlimitIndex = K;
                    break;
                }
            } else if (arr[mid] > x) {
                R = mid - 1;
            } else {
                L = mid + 1;
            }
        }
        while (lowerLimit < UpperlimitIndex) {
            int mid = lowerLimit + UpperlimitIndex;
            mid = mid / 2;
            if (arr[mid] == x) {
                return mid;
            } else {
                if (arr[mid] > x) {
                    UpperlimitIndex = mid - 1;
                } else {
                    lowerLimit = mid + 1;
                }
            }
        }
        return -1;
    }
    public static void main(String args[]){
        Scanner sc=new Scanner(System.in);
        int N=sc.nextInt();
        int[]arr=new int[N];
        for(int j=0;j<N;j+=1){
            arr[j]=sc.nextInt();
        }
        int requiredelement=sc.nextInt();
        int index=find(requiredelement,arr);
        System.out.println(index);




    }
}