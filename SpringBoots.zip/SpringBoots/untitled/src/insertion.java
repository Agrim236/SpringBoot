import java.util.*;
import java.lang.*;
public class insertion {
    public static int BinarySearch(int[]arr,int key){
        int low=0;
        int high=arr.length-1;
        while(low<=high){
            int mid=low+high;
            mid=mid/2;
            if(arr[0]>=key){
                return 0;
            }
            else if(arr[mid]>=key&&arr[mid-1]<key){
                return mid;
            }else if(arr[arr.length-1]<key){
                return arr.length-1;
            }
        }
        return -1;
    }
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        int N=sc.nextInt();
        int[] arr=new int[N];
        for(int i=0;i<N;i++){
            arr[i]=sc.nextInt();
        }
        int key=sc.nextInt();
        System.out.println(BinarySearch(arr,key));
    }
}
