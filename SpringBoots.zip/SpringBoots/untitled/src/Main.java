import java.util.*;
import java.lang.*;


public class Main {
    public static int BinarySearch(int[] arr, int key){
        int low = 0;
        int high = arr.length - 1;
        while(low<=high){
            int mid=high+low;
            mid=mid/2;
            if(mid>0&&arr[mid]>=key&&arr[mid-1]<key){
                return mid;
            }else if(mid>0&&arr[mid]>=key&&arr[mid-1]>=key){
                high = mid-1;
            }else{
                low = mid+1;
            }
        }
        return -1;
    }
    public static void main (String[] args)
    {
        Scanner sc=new Scanner(System.in);
        int T=sc.nextInt();
        for(int i=0;i<T;i++){
            int N=sc.nextInt();
            int[]A=new int[N];
            for(int j=0;j<N;j++){
                A[j]=sc.nextInt();
            }
            int target=sc.nextInt();
            System.out.println(BinarySearch(A,target));
        }
    }
}
